package Controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import Model.Arbitro;

public class ControllerModificarArbitro {
	
	
	public final static String URL = "jdbc:mysql://ligafutbol.csiagfyvzpdu.eu-west-3.rds.amazonaws.com:3306/liga_futbol";
	public final static String USER = "usuario1";
	public final static String PASSWORD = "Usuario1.";
	private static Connection con;

	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(URL, USER, PASSWORD);

			System.out.println("Conexión realizada con éxito.");

		} catch (Exception e) {
			System.out.println("Error al realizar la conexión.");
			System.out.println(e);
		}
	}
	
	
	public static ArrayList <Arbitro> modificarArbitro(int Licencia){
		ArrayList<Arbitro> modificararbitro = new ArrayList<Arbitro>();
		
		try {
			String sentenciaSql= "update liga_futbol.arbitro set nombre=nombre , apellido=Apellidos ,licecia=Licencia";
			
					PreparedStatement st = con.prepareStatement(sentenciaSql); 
			st.setInt(1,Licencia);


			ResultSet rs = st.executeQuery();

			while(rs.next()) {
				Arbitro arbitroTemporal = new Arbitro();

				int licencia = rs.getInt("Licencia");
				String nombre = rs.getString("Nombre");
				String apellidos = rs.getString("Apellidos");

				arbitroTemporal.setLicencia(licencia);
				arbitroTemporal.setNombre(nombre);
				arbitroTemporal.setApellidos(apellidos);

				modificararbitro.add(arbitroTemporal);
			}
			
			
		} catch (Exception e) {
			System.out.println(e);
		}

		
		return modificararbitro;
		
	}
	

}
